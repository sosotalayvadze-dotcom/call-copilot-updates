# Local Georgian speech: sources, licenses and attribution

Call Copilot Version 14 can transcribe Georgian on this Mac with a model from NVIDIA. Nothing below is
bundled in the app or in its source repository: the model and the Python packages are downloaded to
`~/Library/Application Support/CallCopilot/local-stt` when you press **Set up** (or run `provision.sh`).

## Models (downloaded, used unmodified)

| Model | Use | Revision (pinned) | SHA-256 | License |
|---|---|---|---|---|
| [nvidia/stt_ka_fastconformer_hybrid_transducer_ctc_large_streaming_80ms_pc](https://huggingface.co/nvidia/stt_ka_fastconformer_hybrid_transducer_ctc_large_streaming_80ms_pc) | live (true streaming, cache-aware) | `5953d9255a22736a04996c742b61da18a73d0d56` | `e43e7a6c824f38fe3842eb27271f528bed6b59a0ed5062dcae5997dfa95239df` | CC BY 4.0 |
| [nvidia/stt_ka_fastconformer_hybrid_large_pc](https://huggingface.co/nvidia/stt_ka_fastconformer_hybrid_large_pc) | accuracy comparison only (offline; never presented as streaming) | `bdfd7871e0574001e650e741d6201d40205db6bb` | `462fb9a0bafabc3cd1cb73c3c551ace290025bbef20eecb1a564607d22bc133a` | CC BY 4.0 |

Attribution: models by NVIDIA, trained with NVIDIA NeMo on Mozilla Common Voice 17.0 and Google FLEURS
Georgian data, licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). No changes were
made to the model files. The model name's "80 ms" is the model's look-ahead, not a promise about how fast
answers appear in the app.

NVIDIA's published accuracy (Transducer decoder, greedy): WER 7.44 % on the Common Voice test set and 16 %
on FLEURS. These are NVIDIA's numbers on read speech, not measurements of this app on phone calls.

## Code

- The streaming loop in `ka_stream_worker.py` follows NVIDIA NeMo's cache-aware microphone example
  (`tutorials/asr/Online_ASR_Microphone_Demo_Cache_Aware_Streaming.ipynb`, Apache License 2.0).
- Python packages: see `requirements.lock` (each package keeps its own license).

## Cost

"Free" means there is no per-minute cloud bill. The model still uses disk space (about 3 GB with the
Python packages), memory, processor time and battery on this Mac.
