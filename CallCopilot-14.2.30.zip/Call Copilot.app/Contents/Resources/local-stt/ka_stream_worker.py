#!/usr/bin/env python3
"""Call Copilot Version 14: local Georgian speech worker.

Runs NVIDIA's cache-aware streaming FastConformer for Georgian on this Mac (CPU or Apple's MPS), for up
to two simultaneous audio streams (your microphone and the call audio) that never share decoder state.
The app starts it with the private Python environment made by provision.sh and talks to it over a Unix
socket in a folder only this user can open. No audio or text is written to disk, and network access is
blocked inside this process (the model is loaded from the local file downloaded at setup).

Model: nvidia/stt_ka_fastconformer_hybrid_transducer_ctc_large_streaming_80ms_pc (CC BY 4.0, see NOTICE).
The streaming loop follows NVIDIA NeMo's cache-aware microphone example
(tutorials/asr/Online_ASR_Microphone_Demo_Cache_Aware_Streaming.ipynb, Apache-2.0).

Protocol (both directions): 4-byte big-endian length, then one kind byte, then the body.
  kind 1: UTF-8 JSON.  kind 2 (app -> worker): audio = stream (uint32 BE) + sequence (uint64 BE) + PCM.
Audio is 16 kHz mono signed 16-bit little-endian PCM. The first message must be
{"type": "hello", "token": ...} with the token the app wrote to this process's standard input.
"""
import argparse
import collections
import hmac
import json
import math
import os
import socket
import stat
import struct
import sys
import threading
import time
import unicodedata

PROTOCOL = 1
SAMPLE_RATE = 16000
MAX_FRAME = 1 << 20
KIND_JSON = 1
KIND_AUDIO = 2
# Two live streams (microphone, call audio) plus two finishing their last sentence during a restart.
MAX_STREAMS = 4


class ProtocolError(Exception):
    pass


# ---------------------------------------------------------------------------------------------------
# Network guard: after setup, the worker never needs the network. Only Unix sockets may connect.

def block_network():
    real_connect = socket.socket.connect
    real_connect_ex = socket.socket.connect_ex

    def refuse(*_args, **_kwargs):
        raise OSError("network access is blocked in the local speech worker")

    def connect(self, address):
        if self.family != socket.AF_UNIX:
            refuse()
        return real_connect(self, address)

    def connect_ex(self, address):
        if self.family != socket.AF_UNIX:
            refuse()
        return real_connect_ex(self, address)

    socket.socket.connect = connect
    socket.socket.connect_ex = connect_ex
    socket.create_connection = refuse
    socket.getaddrinfo = refuse
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["WANDB_MODE"] = "disabled"
    os.environ.pop("HF_TOKEN", None)


# ---------------------------------------------------------------------------------------------------
# Framing

def read_exact(conn, n):
    buf = bytearray()
    while len(buf) < n:
        part = conn.recv(n - len(buf))
        if not part:
            raise EOFError("connection closed")
        buf += part
    return bytes(buf)


def read_frame(conn):
    (length,) = struct.unpack(">I", read_exact(conn, 4))
    if length < 1 or length > MAX_FRAME:
        raise ProtocolError("frame size %d out of range" % length)
    payload = read_exact(conn, length)
    return payload[0], payload[1:]


def encode_frame(kind, body):
    return struct.pack(">I", len(body) + 1) + bytes([kind]) + body


def encode_json(obj):
    return encode_frame(KIND_JSON, json.dumps(obj, ensure_ascii=False).encode("utf-8"))


def parse_audio(body):
    if len(body) < 12:
        raise ProtocolError("audio frame too short")
    stream, seq = struct.unpack(">IQ", body[:12])
    pcm = body[12:]
    if len(pcm) % 2:
        raise ProtocolError("audio frame has an odd number of bytes")
    return stream, seq, pcm


# ---------------------------------------------------------------------------------------------------
# Engines. `FakeEngine` lets the protocol and stream handling be tested without the model.

class FakeEngine:
    """Deterministic stand-in: one letter per chunk that carries sound."""
    name = "fake"
    revision = "test"
    device = "cpu"
    decoder = "fake"
    fallbacks = []
    load_ms = 0.0
    chunk_samples = 2559

    def new_state(self):
        return {"letters": ""}

    def step(self, state, samples):
        if samples and max(abs(s) for s in samples) > 0.01:
            state["letters"] += "ა"
        return state["letters"]

    def flush(self, state, samples):
        return self.step(state, samples)

    def describe(self):
        return {"model": self.name, "revision": self.revision, "device": self.device, "decoder": self.decoder,
                "fallbacks": self.fallbacks, "load_ms": self.load_ms, "chunk_ms": self.chunk_samples * 1000.0 / SAMPLE_RATE}


class NemoEngine:
    """NVIDIA cache-aware streaming FastConformer (hybrid RNN-T/CTC). One shared read-only model; every
    stream has its own feature cache, encoder caches and decoder hypotheses."""

    ENCODER_STEP_MS = 80

    def __init__(self, model_path, device="auto", decoder="rnnt", threads=4, manifest=None, lookahead_ms=80):
        self.model_path = model_path
        self.lookahead_ms = lookahead_ms
        self.requested_device = device
        self.decoder = decoder
        self.threads = threads
        self.manifest = manifest or {}
        self.name = self.manifest.get("repo", os.path.basename(model_path))
        self.revision = self.manifest.get("revision", "unknown")
        self.fallbacks = []
        self.device = "cpu"
        self.load_ms = 0.0
        self.chunk_samples = 0

    def load(self):
        os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
        started = time.monotonic()
        import warnings
        import torch
        torch.set_num_threads(max(1, int(self.threads)))
        self.torch = torch
        wanted = self.requested_device
        mps = bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available())
        if wanted == "mps" and not mps:
            self.fallbacks.append("MPS is not available here; using the CPU")
        device = "mps" if wanted in ("auto", "mps") and mps else "cpu"
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                self._load_on(device)
                self._warm_up()
            self._note_cpu_fallbacks(caught)
        except Exception as e:  # an unsupported MPS operation: correctness first, run on the CPU
            if device == "cpu":
                raise
            self.fallbacks.append("MPS failed (%s); using the CPU" % type(e).__name__)
            device = "cpu"
            self._load_on(device)
            self._warm_up()
        self.device = device
        self.load_ms = (time.monotonic() - started) * 1000.0

    def _note_cpu_fallbacks(self, caught):
        for w in caught:
            text = str(w.message)
            if "fall back to run on the CPU" in text or "not currently supported on the MPS backend" in text:
                op = text.split("'")[1] if "'" in text else text[:80]
                note = "operation %s runs on the CPU" % op
                if note not in self.fallbacks:
                    self.fallbacks.append(note)

    def _load_on(self, device):
        import copy
        from omegaconf import OmegaConf, open_dict
        import nemo.collections.asr as nemo_asr
        from nemo.collections.asr.models.ctc_bpe_models import EncDecCTCModelBPE
        torch = self.torch
        model = nemo_asr.models.ASRModel.restore_from(self.model_path, map_location=torch.device(device))
        model.change_decoding_strategy(decoder_type=self.decoder)
        cfg = model.cfg.decoding
        with open_dict(cfg):
            cfg.strategy = "greedy"
            cfg.preserve_alignments = False
            if hasattr(model, "joint"):
                cfg.greedy.max_symbols = 10
                cfg.fused_batch_size = -1
        model.change_decoding_strategy(cfg, decoder_type=self.decoder)
        model.eval()
        # The checkpoint was trained with several look-aheads and its default is not the 80 ms in its name
        # (CI 2026-10-30: [70, 13] = 1040 ms). Choose the requested one, as NVIDIA's example does.
        enc = model.encoder
        options = [list(o) for o in (getattr(enc, "att_context_size_all", None) or [enc.att_context_size])]
        want = max(0, int(round(self.lookahead_ms / float(self.ENCODER_STEP_MS))))
        chosen = next((o for o in options if o[1] == want), None)
        if chosen is None:
            chosen = min(options, key=lambda o: abs(o[1] - want))
            self.fallbacks.append("look-ahead %d ms is not offered; using %d ms" % (self.lookahead_ms, chosen[1] * self.ENCODER_STEP_MS))
        if list(enc.att_context_size) != chosen and hasattr(enc, "set_default_att_context_size"):
            enc.set_default_att_context_size(chosen)
        self.att_context_options = options
        pre_cfg = copy.deepcopy(model._cfg)
        OmegaConf.set_struct(pre_cfg.preprocessor, False)
        pre_cfg.preprocessor.dither = 0.0
        pre_cfg.preprocessor.pad_to = 0
        pre_cfg.preprocessor.normalize = "None"
        pre = EncDecCTCModelBPE.from_config_dict(pre_cfg.preprocessor)
        pre.to(model.device)
        self.model = model
        self.preprocessor = pre
        self.pre_encode_cache_size = model.encoder.streaming_cfg.pre_encode_cache_size[1]
        self.num_channels = model.cfg.preprocessor.features
        # One encoder step plus the model's right (look-ahead) context, as in NVIDIA's example.
        lookahead_steps = model.encoder.att_context_size[1]
        chunk_ms = (lookahead_steps + 1) * self.ENCODER_STEP_MS
        self.chunk_samples = int(SAMPLE_RATE * chunk_ms / 1000) - 1
        self.att_context_size = list(model.encoder.att_context_size)

    def _warm_up(self):
        state = self.new_state()
        for _ in range(3):
            self.step(state, [0.0] * self.chunk_samples)

    def new_state(self):
        torch = self.torch
        c_ch, c_t, c_len = self.model.encoder.get_initial_cache_state(batch_size=1)
        return {
            "cache_last_channel": c_ch, "cache_last_time": c_t, "cache_last_channel_len": c_len,
            "cache_pre_encode": torch.zeros((1, self.num_channels, self.pre_encode_cache_size), device=self.model.device),
            "previous_hypotheses": None, "pred_out_stream": None, "text": "",
        }

    def step(self, state, samples, last=False):
        torch = self.torch
        with torch.inference_mode():
            audio = torch.tensor(samples, dtype=torch.float32, device=self.model.device).unsqueeze(0)
            length = torch.tensor([audio.shape[1]], device=self.model.device)
            processed, processed_len = self.preprocessor(input_signal=audio, length=length)
            processed = torch.cat([state["cache_pre_encode"], processed], dim=-1)
            processed_len = processed_len + state["cache_pre_encode"].shape[2]
            state["cache_pre_encode"] = processed[:, :, -self.pre_encode_cache_size:]
            (state["pred_out_stream"], texts, state["cache_last_channel"], state["cache_last_time"],
             state["cache_last_channel_len"], state["previous_hypotheses"]) = self.model.conformer_stream_step(
                processed_signal=processed,
                processed_signal_length=processed_len,
                cache_last_channel=state["cache_last_channel"],
                cache_last_time=state["cache_last_time"],
                cache_last_channel_len=state["cache_last_channel_len"],
                keep_all_outputs=last,
                previous_hypotheses=state["previous_hypotheses"],
                previous_pred_out=state["pred_out_stream"],
                drop_extra_pre_encoded=None,
                return_transcription=True,
            )
        first = texts[0] if texts else ""
        state["text"] = getattr(first, "text", first) or ""
        return state["text"]

    def flush(self, state, samples):
        """End of a sentence: the samples left before the end (less than one chunk), padded with silence,
        go through the model with keep_all_outputs, so the last words held back for the look-ahead are
        decoded too (NVIDIA's file example does the same on its last chunk). The caller then starts the
        next sentence with a fresh state."""
        padded = list(samples) + [0.0] * max(0, self.chunk_samples - len(samples))
        return self.step(state, padded, last=True)

    def describe(self):
        return {"model": self.name, "revision": self.revision, "device": self.device, "decoder": self.decoder,
                "fallbacks": self.fallbacks, "load_ms": round(self.load_ms), "threads": self.threads,
                "chunk_ms": round(self.chunk_samples * 1000.0 / SAMPLE_RATE, 1),
                "att_context_size": getattr(self, "att_context_size", None),
                "lookahead_ms": (getattr(self, "att_context_size", [0, 0])[1]) * self.ENCODER_STEP_MS,
                "att_context_options": getattr(self, "att_context_options", None),
                "torch": getattr(self.torch, "__version__", "?")}


# ---------------------------------------------------------------------------------------------------
# Streams: bounded queues, ordered commits, partial/final events. Engine-agnostic and thread-safe.

class Stream:
    def __init__(self, sid, engine):
        self.id = sid
        self.state = engine.new_state()
        self.samples = collections.deque()      # float samples waiting for a full chunk
        self.arrivals = collections.deque()     # (received sample count at the end of a frame, arrival time)
        self.received = 0                       # samples received
        self.processed = 0                      # samples run through the model (or dropped)
        self.dropped = 0
        self.commits = collections.deque()      # received-sample positions where a sentence ended
        self.segment = 0
        self.segment_start = 0
        self.revision = 0
        self.text = ""
        self.last_seq = None
        self.busy_seconds = 0.0
        self.audio_seconds = 0.0
        self.max_queue_ms = 0.0


class Worker:
    def __init__(self, engine, emit, max_queue_seconds=8.0, max_segment_seconds=30.0, clock=time.monotonic):
        self.engine = engine
        self.emit = emit
        self.max_queue = int(max_queue_seconds * SAMPLE_RATE)
        self.max_segment = int(max_segment_seconds * SAMPLE_RATE)
        self.clock = clock
        self.streams = {}
        self.lock = threading.Condition()
        self.turn = 0

    # Control (reader thread) -------------------------------------------------------------------
    def open(self, sid):
        """A refused stream gets an error of its own; the other streams on the connection go on."""
        with self.lock:
            if sid in self.streams:
                return
            refused = len(self.streams) >= MAX_STREAMS
            if not refused:
                self.streams[sid] = Stream(sid, self.engine)
        if refused:
            self.emit({"type": "error", "stream": sid, "code": "streams", "message": "at most %d streams at once" % MAX_STREAMS})
        else:
            self.emit({"type": "opened", "stream": sid})

    def close(self, sid):
        with self.lock:
            self.streams.pop(sid, None)

    def reset(self, sid):
        """Forget the audio and decoder state of this stream (a fresh start after a pause). Sentence
        numbers go on, so a sentence after the pause never reuses an earlier sentence's number."""
        with self.lock:
            old = self.streams.get(sid)
            if old is not None:
                fresh = Stream(sid, self.engine)
                fresh.segment = old.segment + (1 if old.text else 0)
                self.streams[sid] = fresh

    def push(self, sid, seq, pcm):
        now = self.clock()
        events = []
        with self.lock:
            st = self.streams.get(sid)
            if st is None:
                # A frame that crossed a "close" on the way: dropped, the connection goes on.
                return
            if st.last_seq is not None and seq != st.last_seq + 1:
                events.append({"type": "warning", "stream": sid,
                               "message": "audio frames %d-%d missing" % (st.last_seq + 1, seq - 1)})
            st.last_seq = seq
            values = struct.unpack("<%dh" % (len(pcm) // 2), pcm)
            st.samples.extend(v / 32768.0 for v in values)
            st.received += len(values)
            st.arrivals.append((st.received, now))
            # Bounded: when the model cannot keep up, the oldest audio is dropped and reported, never
            # allowed to pile up into growing delay.
            overflow = len(st.samples) - self.max_queue
            if overflow > 0:
                for _ in range(overflow):
                    st.samples.popleft()
                start = st.processed
                st.processed += overflow
                st.dropped += overflow
                events.append({"type": "gap", "stream": sid, "start_sample": start, "end_sample": st.processed,
                               "reason": "local model fell behind; oldest audio dropped"})
            self.lock.notify()
        for e in events:
            self.emit(e)

    def commit(self, sid):
        with self.lock:
            st = self.streams.get(sid)
            if st is not None:
                st.commits.append(st.received)
                self.lock.notify()

    # Processing (inference thread) -----------------------------------------------------------------
    def _pick(self):
        """Next stream with work, round robin; None when idle. Call with the lock held."""
        ids = sorted(self.streams)
        for k in range(len(ids)):
            sid = ids[(self.turn + k) % len(ids)]
            st = self.streams[sid]
            if len(st.samples) >= self.engine.chunk_samples or self._commit_due(st):
                self.turn = (self.turn + k + 1) % max(1, len(ids))
                return st
        return None

    def _commit_due(self, st):
        if st.commits and st.commits[0] - st.processed < self.engine.chunk_samples:
            return True
        return st.processed - st.segment_start >= self.max_segment and bool(st.text)

    def run_once(self, wait=None):
        with self.lock:
            st = self._pick()
            if st is None:
                if wait:
                    self.lock.wait(wait)
                return False
            chunk = None
            tail = None
            if not self._commit_due(st):
                chunk = [st.samples.popleft() for _ in range(self.engine.chunk_samples)]
            else:
                # The end of the sentence: what is left before the commit point (less than a chunk).
                if st.commits and st.commits[0] - st.processed < self.engine.chunk_samples:
                    upto = max(0, min(len(st.samples), st.commits.popleft() - st.processed))
                    reason = "end of speech"
                else:
                    upto = 0
                    reason = "sentence longer than %d s" % (self.max_segment // SAMPLE_RATE)
                tail = [st.samples.popleft() for _ in range(upto)]
        events = []
        if chunk is not None:
            began = self.clock()
            text = self.engine.step(st.state, chunk)
            spent = self.clock() - began
            with self.lock:
                if self.streams.get(st.id) is not st:
                    return True    # closed or reset meanwhile: its results are not used
                st.processed += len(chunk)
                st.busy_seconds += spent
                st.audio_seconds += len(chunk) / float(SAMPLE_RATE)
                age = self._queue_age(st)
                st.max_queue_ms = max(st.max_queue_ms, age)
                text = normalize(text)
                if text and text != st.text:
                    st.text = text
                    st.revision += 1
                    events.append({"type": "partial", "stream": st.id, "segment": st.segment, "revision": st.revision,
                                   "text": text, "start_sample": st.segment_start, "end_sample": st.processed,
                                   "queue_ms": round(age)})
        else:
            began = self.clock()
            text = normalize(self.engine.flush(st.state, tail))
            spent = self.clock() - began
            with self.lock:
                if self.streams.get(st.id) is not st:
                    return True
                st.processed += len(tail)
                st.busy_seconds += spent
                st.audio_seconds += len(tail) / float(SAMPLE_RATE)
                final = text or st.text
                if final:
                    events.append({"type": "final", "stream": st.id, "segment": st.segment, "revision": st.revision + 1,
                                   "text": final, "start_sample": st.segment_start, "end_sample": st.processed,
                                   "reason": reason})
                    st.segment += 1
                # Every sentence starts fresh (caches included): the flush padded the stream with silence.
                st.state = self.engine.new_state()
                st.revision = 0
                st.text = ""
                st.segment_start = st.processed
        for e in events:
            self.emit(e)
        return True

    def _queue_age(self, st):
        """How long ago the oldest unprocessed sample arrived, in ms. Call with the lock held."""
        while st.arrivals and st.arrivals[0][0] <= st.processed:
            st.arrivals.popleft()
        if not st.arrivals or not st.samples:
            return 0.0
        return (self.clock() - st.arrivals[0][1]) * 1000.0

    def health(self):
        with self.lock:
            out = []
            for st in self.streams.values():
                rtf = st.busy_seconds / st.audio_seconds if st.audio_seconds else None
                out.append({"type": "health", "stream": st.id, "queue_ms": round(self._queue_age(st)),
                            "max_queue_ms": round(st.max_queue_ms), "rtf": None if rtf is None else round(rtf, 3),
                            "dropped_ms": round(st.dropped * 1000.0 / SAMPLE_RATE), "audio_s": round(st.audio_seconds, 1)})
        return out


def normalize(text):
    """Display text: Unicode NFC and single spaces (the model's raw text is otherwise kept as is)."""
    return " ".join(unicodedata.normalize("NFC", text or "").split())


# ---------------------------------------------------------------------------------------------------
# Server

class Connection:
    def __init__(self, conn):
        self.conn = conn
        self.send_lock = threading.Lock()
        self.alive = True

    def send(self, obj):
        data = encode_json(obj)
        with self.send_lock:
            if not self.alive:
                return
            try:
                self.conn.sendall(data)
            except OSError:
                self.alive = False


def check_private_dir(path):
    st = os.stat(path)
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != os.getuid() or st.st_mode & 0o077:
        raise SystemExit("socket folder must be a private folder (mode 700) owned by this user: %s" % path)


def serve(args, engine, token):
    folder = os.path.dirname(os.path.abspath(args.socket))
    check_private_dir(folder)
    if os.path.exists(args.socket):
        os.unlink(args.socket)
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    old = os.umask(0o177)
    try:
        server.bind(args.socket)
    finally:
        os.umask(old)
    os.chmod(args.socket, 0o600)
    server.listen(1)
    status("listening")
    loaded = threading.Event()
    failure = []

    def load():
        try:
            if hasattr(engine, "load"):
                engine.load()
            status("ready", engine.describe())
        except Exception as e:  # reported to the app, never silently ignored
            failure.append("%s: %s" % (type(e).__name__, str(e)[:300]))
            status("failed", {"error": failure[0]})
        loaded.set()

    threading.Thread(target=load, daemon=True).start()
    while True:
        conn, _ = server.accept()
        handle_client(Connection(conn), engine, token, loaded, failure)
        if args.once:
            break


def handle_client(client, engine, token, loaded, failure):
    conn = client.conn
    conn.settimeout(5)
    try:
        kind, body = read_frame(conn)
        hello = json.loads(body.decode("utf-8")) if kind == KIND_JSON else {}
        if hello.get("type") != "hello" or not hmac.compare_digest(str(hello.get("token", "")), token):
            client.send({"type": "error", "code": "auth", "message": "not authorized"})
            conn.close()
            return
    except Exception:
        conn.close()
        return
    conn.settimeout(None)
    client.send({"type": "status", "state": "loading" if not loaded.is_set() else ("failed" if failure else "ready"),
                 "protocol": PROTOCOL})
    loaded.wait()
    if failure:
        client.send({"type": "error", "code": "load", "message": failure[0]})
        conn.close()
        return
    client.send(dict({"type": "ready", "protocol": PROTOCOL}, **engine.describe()))
    worker = Worker(engine, client.send)
    stop = threading.Event()

    def infer():
        last_health = time.monotonic()
        while not stop.is_set():
            try:
                worker.run_once(wait=0.05)
            except Exception as e:
                client.send({"type": "error", "code": "decode", "message": "%s: %s" % (type(e).__name__, str(e)[:200])})
                time.sleep(0.2)
            if time.monotonic() - last_health >= 1.0:
                last_health = time.monotonic()
                for h in worker.health():
                    client.send(h)

    thread = threading.Thread(target=infer, daemon=True)
    thread.start()
    try:
        while client.alive:
            kind, body = read_frame(conn)
            if kind == KIND_AUDIO:
                sid, seq, pcm = parse_audio(body)
                worker.push(sid, seq, pcm)
                continue
            if kind != KIND_JSON:
                raise ProtocolError("unknown frame kind %d" % kind)
            msg = json.loads(body.decode("utf-8"))
            t = msg.get("type")
            sid = int(msg.get("stream", 0))
            if t == "open":
                worker.open(sid)
            elif t == "commit":
                worker.commit(sid)
            elif t == "reset":
                worker.reset(sid)
            elif t == "close":
                worker.close(sid)
            elif t == "ping":
                client.send({"type": "pong", "id": msg.get("id")})
            elif t == "shutdown":
                break
            else:
                raise ProtocolError("unknown message type")
    except (EOFError, OSError):
        pass
    except (ProtocolError, ValueError) as e:
        client.send({"type": "error", "code": "protocol", "message": str(e)[:200]})
    finally:
        stop.set()
        thread.join(timeout=2)
        client.alive = False
        try:
            conn.close()
        except OSError:
            pass


def status(state, extra=None):
    """One JSON line on standard output for the app's log (never audio or transcript text)."""
    line = {"worker": state}
    if extra:
        line.update(extra)
    sys.stdout.write(json.dumps(line, ensure_ascii=False) + "\n")
    sys.stdout.flush()


# ---------------------------------------------------------------------------------------------------
# Self-test and benchmark: the same Worker code, fed from WAV files.

def load_wav(path):
    import numpy as np
    import soundfile as sf
    audio, rate = sf.read(path, dtype="float32", always_2d=True)
    audio = audio.mean(axis=1)    # downmix within this one file only
    if rate != SAMPLE_RATE:
        import librosa
        audio = librosa.resample(audio, orig_sr=rate, target_sr=SAMPLE_RATE)
    return np.clip(audio, -1.0, 1.0)


def wer_cer(reference, hypothesis):
    def fold(s):
        s = unicodedata.normalize("NFC", s).lower()
        return "".join(c if c.isalnum() or c.isspace() else " " for c in s).split()

    def distance(a, b):
        prev = list(range(len(b) + 1))
        for i, x in enumerate(a, 1):
            cur = [i] + [0] * len(b)
            for j, y in enumerate(b, 1):
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x != y))
            prev = cur
        return prev[-1]

    r, h = fold(reference), fold(hypothesis)
    rc, hc = list("".join(r)), list("".join(h))
    return (distance(r, h) / max(1, len(r)), distance(rc, hc) / max(1, len(rc)))


def selftest(args, engine):
    started = time.monotonic()
    engine.load()
    refs = {}
    if args.references:
        with open(args.references, encoding="utf-8") as f:
            for line in f:
                if "\t" in line:
                    name, text = line.rstrip("\n").split("\t", 1)
                    refs[name] = text
    results = []
    files = list(args.selftest)
    for group_start in range(0, len(files), max(1, args.streams)):
        group = files[group_start:group_start + max(1, args.streams)]
        audios = [load_wav(p) for p in group]
        events = []
        lock = threading.Lock()

        def emit(e):
            e["at"] = time.monotonic()
            with lock:
                events.append(e)

        worker = Worker(engine, emit)
        for i in range(len(group)):
            worker.open(i)
        frame = SAMPLE_RATE // 50   # 20 ms frames, like the app
        t0 = time.monotonic()
        stop = threading.Event()

        def infer():
            while not stop.is_set():
                worker.run_once(wait=0.01)

        thread = threading.Thread(target=infer, daemon=True)
        thread.start()
        longest = max(len(a) for a in audios)
        seq = [0] * len(group)
        for pos in range(0, longest, frame):
            for i, audio in enumerate(audios):
                if pos < len(audio):
                    piece = audio[pos:pos + frame]
                    pcm = struct.pack("<%dh" % len(piece), *[int(round(max(-1.0, min(1.0, float(v))) * 32767)) for v in piece])
                    worker.push(i, seq[i], pcm)
                    seq[i] += 1
            if args.realtime:
                due = t0 + (pos + frame) / float(SAMPLE_RATE)
                time.sleep(max(0.0, due - time.monotonic()))
        audio_end = time.monotonic()
        for i in range(len(group)):
            worker.commit(i)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            with lock:
                done = sum(1 for e in events if e["type"] == "final") >= len(group)
            if done:
                break
            time.sleep(0.02)
        health = worker.health()
        stop.set()
        thread.join(timeout=2)
        for i, path in enumerate(group):
            mine = [e for e in events if e.get("stream") == i]
            partials = [e for e in mine if e["type"] == "partial"]
            final = next((e for e in mine if e["type"] == "final"), None)
            text = final["text"] if final else (partials[-1]["text"] if partials else "")
            row = {"file": os.path.basename(path), "streams_at_once": len(group), "audio_s": round(len(audios[i]) / SAMPLE_RATE, 2),
                   "first_partial_ms_after_start": round((partials[0]["at"] - t0) * 1000) if partials else None,
                   "final_ms_after_audio_end": round((final["at"] - audio_end) * 1000) if final else None,
                   "partials": len(partials), "text": text, "health": next((h for h in health if h["stream"] == i), None)}
            ref = refs.get(os.path.basename(path))
            if ref is not None:
                w, c = wer_cer(ref, text)
                row.update({"reference": ref, "wer": round(w, 4), "cer": round(c, 4)})
            if args.compare_offline and hasattr(engine, "model"):
                out = engine.model.transcribe([path], verbose=False)
                first = out[0] if isinstance(out, list) else out
                if isinstance(first, list):
                    first = first[0]
                offline = normalize(getattr(first, "text", first))
                row["offline_text"] = offline
                row["matches_offline"] = offline == text
            results.append(row)
    report = {"engine": engine.describe(), "realtime": bool(args.realtime), "streams": args.streams,
              "total_s": round(time.monotonic() - started, 1), "results": results}
    out = json.dumps(report, ensure_ascii=False, indent=2)
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            f.write(out)
    print(out)


def check():
    """Versions of the runtime (no model load, no audio)."""
    info = {"python": sys.version.split()[0], "platform": sys.platform}
    try:
        import platform
        info["machine"] = platform.machine()
        info["macos"] = platform.mac_ver()[0]
        import torch
        info["torch"] = torch.__version__
        info["mps_available"] = bool(torch.backends.mps.is_available())
        import nemo
        info["nemo"] = nemo.__version__
    except Exception as e:
        info["error"] = "%s: %s" % (type(e).__name__, str(e)[:200])
    print(json.dumps(info))
    return 0 if "error" not in info else 1


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--socket", help="Unix socket path (its folder must be private, mode 700)")
    p.add_argument("--model", help="path to the .nemo file downloaded by provision.py")
    p.add_argument("--manifest", help="manifest.json written by provision.py")
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "mps"])
    p.add_argument("--decoder", default="rnnt", choices=["rnnt", "ctc"])
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--lookahead-ms", type=int, default=80, help="model look-ahead (80 ms = the streaming setting)")
    p.add_argument("--once", action="store_true", help="serve one connection, then exit")
    p.add_argument("--fake", action="store_true", help="protocol test engine (no model)")
    p.add_argument("--check", action="store_true", help="print runtime versions and exit")
    p.add_argument("--selftest", nargs="*", help="WAV files to stream through the model")
    p.add_argument("--streams", type=int, default=1, help="self-test: streams at the same time (1 or 2)")
    p.add_argument("--realtime", action="store_true", help="self-test: feed audio at real-time speed")
    p.add_argument("--references", help="self-test: TSV of file name, reference text")
    p.add_argument("--compare-offline", action="store_true", help="self-test: also transcribe each file offline")
    p.add_argument("--json", help="self-test: also write the report here")
    p.add_argument("--allow-network", action="store_true", help="development only: do not block the network")
    args = p.parse_args(argv)
    if args.check:
        return check()
    if not args.allow_network:
        block_network()
    manifest = None
    if args.manifest and os.path.exists(args.manifest):
        with open(args.manifest, encoding="utf-8") as f:
            manifest = json.load(f)
    engine = FakeEngine() if args.fake else NemoEngine(args.model, args.device, args.decoder, args.threads, manifest,
                                                       lookahead_ms=args.lookahead_ms)
    if args.selftest is not None:
        if args.fake:
            raise SystemExit("--selftest needs the real model")
        selftest(args, engine)
        return 0
    if not args.socket:
        raise SystemExit("--socket is required")
    token = sys.stdin.readline().strip()
    if len(token) < 32:
        raise SystemExit("expected the session token on standard input")

    def exit_with_app():
        # The app keeps standard input open; when it quits (or crashes), the worker ends too.
        while sys.stdin.read(1024):
            pass
        os._exit(0)

    threading.Thread(target=exit_with_app, daemon=True).start()
    serve(args, engine, token)
    return 0


if __name__ == "__main__":
    sys.exit(main())
