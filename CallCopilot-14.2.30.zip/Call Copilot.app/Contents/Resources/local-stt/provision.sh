#!/bin/bash
# Call Copilot Version 14: sets up the local Georgian speech model on this Mac (Apple silicon).
#
#   bash provision.sh            (the app runs this from Settings → Georgian speech → Set up)
#
# 1. A private Python 3.12 environment in ~/Library/Application Support/CallCopilot/local-stt/venv,
#    with the exact packages and checksums in requirements.lock (about 2–3 GB).
# 2. The NVIDIA Georgian streaming model (about 460 MB), pinned revision, SHA-256 verified.
# 3. A check that the runtime imports (no audio, no network after this script).
#
# Nothing is installed system-wide and nothing is put in the app's source folder. Delete the folder
# above to remove everything. The model is public, so no token is needed; HF_TOKEN is only used if the
# app passes it for this one run.
set -euo pipefail
set +x   # never trace (a token may be in the environment)

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE="${CALLCOPILOT_LOCAL_STT_HOME:-$HOME/Library/Application Support/CallCopilot/local-stt}"
VENV="$BASE/venv"
MODELS="$BASE/models"

step() { echo "STEP: $*"; }

if [ "$(uname -m)" != "arm64" ]; then
  echo "PROBLEM: the local Georgian model needs a Mac with Apple silicon (this one is $(uname -m))."
  exit 2
fi

mkdir -p "$BASE"
chmod 700 "$BASE"

find_python() {
  for p in python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 \
           /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12; do
    if command -v "$p" >/dev/null 2>&1 && "$p" -c 'import sys; sys.exit(0 if sys.version_info[:2] == (3, 12) else 1)' 2>/dev/null; then
      command -v "$p"
      return 0
    fi
  done
  return 1
}

if [ ! -x "$VENV/bin/python" ] || ! "$VENV/bin/python" -c 'import sys; sys.exit(0 if sys.version_info[:2] == (3, 12) else 1)' 2>/dev/null; then
  step "Creating the private Python 3.12 environment"
  rm -rf "$VENV"
  if PY="$(find_python)"; then
    "$PY" -m venv "$VENV"
  elif command -v uv >/dev/null 2>&1; then
    uv venv --python 3.12 "$VENV"
    uv pip install --python "$VENV/bin/python" pip
  else
    echo "PROBLEM: Python 3.12 was not found. Install it from https://www.python.org/downloads/macos/ (Python 3.12, macOS 64-bit universal2 installer), then press Set up again."
    exit 3
  fi
fi

step "Installing the speech packages (pinned versions with checksums; this takes several minutes the first time)"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-input --quiet --require-hashes --no-deps \
  -r "$HERE/requirements.lock"

step "Downloading the NVIDIA Georgian streaming model (about 460 MB) and checking its checksum"
"$VENV/bin/python" -I "$HERE/provision.py" --models-dir "$MODELS" --model "${CALLCOPILOT_LOCAL_STT_MODELS:-streaming}"
unset HF_TOKEN

step "Checking the runtime"
"$VENV/bin/python" -I "$HERE/ka_stream_worker.py" --check

cp "$HERE/NOTICE.md" "$BASE/NOTICE.md" 2>/dev/null || true
echo "OK: local Georgian speech is set up in $BASE"
