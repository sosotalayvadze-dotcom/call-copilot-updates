#!/usr/bin/env python3
"""Call Copilot Version 14: downloads the pinned NVIDIA Georgian model and checks it.

Run by provision.sh inside the private Python environment. Downloads from the official NVIDIA repository
on Hugging Face at a fixed revision, verifies the SHA-256 checksum, and writes manifest.json beside it.
The models are public: no token is needed. If HF_TOKEN is set for this one process (the app passes it
from the Keychain only when it is saved), it is used for the download and nowhere else.
"""
import argparse
import datetime
import hashlib
import json
import os
import shutil
import sys

# Pinned 2026-10-30 from the Hugging Face API (model revision = git commit of the model repository).
MODELS = {
    "streaming": {
        "repo": "nvidia/stt_ka_fastconformer_hybrid_transducer_ctc_large_streaming_80ms_pc",
        "file": "stt_ka_fastconformer_hybrid_transducer_ctc_large_streaming_80ms_pc.nemo",
        "revision": "5953d9255a22736a04996c742b61da18a73d0d56",
        "sha256": "e43e7a6c824f38fe3842eb27271f528bed6b59a0ed5062dcae5997dfa95239df",
        "size": 459745280,
        "kind": "true streaming (cache-aware, 80 ms look-ahead)",
    },
    "hybrid": {
        "repo": "nvidia/stt_ka_fastconformer_hybrid_large_pc",
        "file": "stt_ka_fastconformer_hybrid_large_pc.nemo",
        "revision": "bdfd7871e0574001e650e741d6201d40205db6bb",
        "sha256": "462fb9a0bafabc3cd1cb73c3c551ace290025bbef20eecb1a564607d22bc133a",
        "size": 459304960,
        "kind": "offline (comparison only; never used as a streaming recognizer)",
    },
}
LICENSE = "CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def provision(name, models_dir):
    spec = MODELS[name]
    target_dir = os.path.join(models_dir, name)
    target = os.path.join(target_dir, spec["file"])
    manifest_path = os.path.join(target_dir, "manifest.json")
    if os.path.exists(target) and os.path.exists(manifest_path):
        with open(manifest_path, encoding="utf-8") as f:
            manifest = json.load(f)
        if manifest.get("sha256") == spec["sha256"] and sha256(target) == spec["sha256"]:
            print(json.dumps({"model": name, "state": "already present and verified"}))
            return manifest

    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"   # never pick up a token stored by other tools
    from huggingface_hub import hf_hub_download

    token = os.environ.pop("HF_TOKEN", None) or False   # False = anonymous
    os.makedirs(target_dir, exist_ok=True)
    download_cache = os.path.join(models_dir, ".download")
    path = hf_hub_download(repo_id=spec["repo"], filename=spec["file"], revision=spec["revision"],
                           cache_dir=download_cache, token=token)
    token = None
    digest = sha256(path)
    if digest != spec["sha256"]:
        shutil.rmtree(download_cache, ignore_errors=True)
        raise SystemExit("checksum mismatch for %s: expected %s, got %s — the download was deleted"
                         % (spec["file"], spec["sha256"], digest))
    tmp = target + ".part"
    shutil.copyfile(path, tmp)
    os.replace(tmp, target)
    shutil.rmtree(download_cache, ignore_errors=True)
    manifest = {
        "model": name, "repo": spec["repo"], "file": spec["file"], "revision": spec["revision"],
        "sha256": digest, "size": os.path.getsize(target), "kind": spec["kind"], "license": LICENSE,
        "source": "https://huggingface.co/%s/tree/%s" % (spec["repo"], spec["revision"]),
        "attribution": "NVIDIA, %s, licensed under CC BY 4.0. Used unmodified." % spec["repo"],
        "downloaded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
    }
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    print(json.dumps({"model": name, "state": "downloaded and verified", "sha256": digest}))
    return manifest


def main(argv=None):
    p = argparse.ArgumentParser(description="Download and verify the local Georgian speech model")
    p.add_argument("--models-dir", required=True)
    p.add_argument("--model", choices=["streaming", "hybrid", "both"], default="streaming")
    args = p.parse_args(argv)
    names = ["streaming", "hybrid"] if args.model == "both" else [args.model]
    for name in names:
        provision(name, args.models_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
